Core/Src/EC_Eth_PHY.o: ../Core/Src/EC_Eth_PHY.c ../Core/Inc/EC_Eth_PHY.h \
 ../Core/Inc/adin1200_stm32.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal.h \
 ../Core/Inc/stm32h7xx_hal_conf.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_def.h \
 ../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h7xx.h \
 ../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h745xx.h \
 ../../Drivers/CMSIS/Include/core_cm7.h \
 ../../Drivers/CMSIS/Include/cmsis_version.h \
 ../../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../Drivers/CMSIS/Include/mpu_armv7.h \
 ../../Drivers/CMSIS/Include/cachel1_armv7.h \
 ../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/system_stm32h7xx.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_mdma.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_eth.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_eth_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_exti.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_cortex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_ll_adc.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_crc.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_crc_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_hsem.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_iwdg.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_tim.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_tim_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_uart.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_uart_ex.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_smbus.h \
 ../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_smbus_ex.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/netif.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/opt.h \
 ../LWIP/Target/lwipopts.h ../Core/Inc/main.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/debug.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/arch.h \
 ../../Middlewares/Third_Party/LwIP/system/arch/cc.h \
 ../../Middlewares/Third_Party/LwIP/system/arch/cpu.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/err.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/ip_addr.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/ip4_addr.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/ip6_addr.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/pbuf.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/stats.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/mem.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/memp.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/memp_std.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/memp_priv.h \
 ../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/mem_priv.h \
 ../LWIP/Target/ethernetif.h
../Core/Inc/EC_Eth_PHY.h:
../Core/Inc/adin1200_stm32.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal.h:
../Core/Inc/stm32h7xx_hal_conf.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_def.h:
../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h7xx.h:
../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h745xx.h:
../../Drivers/CMSIS/Include/core_cm7.h:
../../Drivers/CMSIS/Include/cmsis_version.h:
../../Drivers/CMSIS/Include/cmsis_compiler.h:
../../Drivers/CMSIS/Include/cmsis_gcc.h:
../../Drivers/CMSIS/Include/mpu_armv7.h:
../../Drivers/CMSIS/Include/cachel1_armv7.h:
../../Drivers/CMSIS/Device/ST/STM32H7xx/Include/system_stm32h7xx.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_mdma.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_eth.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_eth_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_exti.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_cortex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_ll_adc.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_crc.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_crc_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_hsem.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_iwdg.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_tim.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_tim_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_uart.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_uart_ex.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_smbus.h:
../../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_smbus_ex.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/netif.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/opt.h:
../LWIP/Target/lwipopts.h:
../Core/Inc/main.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/debug.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/arch.h:
../../Middlewares/Third_Party/LwIP/system/arch/cc.h:
../../Middlewares/Third_Party/LwIP/system/arch/cpu.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/err.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/ip_addr.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/ip4_addr.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/ip6_addr.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/pbuf.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/stats.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/mem.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/memp.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/memp_std.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/memp_priv.h:
../../Middlewares/Third_Party/LwIP/src/include/lwip/priv/mem_priv.h:
../LWIP/Target/ethernetif.h:
